# Militia-Warfare

[http://ashimregmi.github.io/mini-militia](http://ashimregmi.github.io/mini-militia)

![alt tag](https://raw.githubusercontent.com/leapfroglets/militia-warfare/master/images/screencapture-ashimregmi-github-io-mini-militia-1492730719658.png)

Militia-Warfare is a web-based shooting game inspired from Doodle Army 2: Mini Militia and written in plain JavaScript. It tries to replicate the survival mode in the game. A user plays as an officer and the user's role is to shoot down robot units. The user gets 3 lives to shoot down as many robots as he can.  Officer can be maneuvered using 'W', 'A', 'S' and 'D' keys. Officer can target and shoot a robot unit using the mouse.

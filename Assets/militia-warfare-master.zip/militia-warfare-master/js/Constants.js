/**
 * Created by Asim on 4/15/2017.
 */
var TILE_SIZE = 32;